<?php
if(!setlocale(LC_TIME,'zh_CN.UTF-8'))
    setlocale(LC_TIME,'chinese.GB2312');
